import SchoolGameView from './components/SchoolGameView';

// Your existing routes can stay — just render <SchoolGameView /> wherever you want the game.
export default function App() {
  return <SchoolGameView height="100vh" />;
}
