# Maple Grove School Life

A living top-down pixel-art school simulator built with **Phaser 3 + TypeScript + React (Vite)**.
All art (tiles, furniture, characters, emotes) is generated in code — there are no image files to manage.

## Run it on Replit
1. Create a new Repl → **Import** → upload this zip (or create a "React + TypeScript (Vite)" Repl and copy the `src/` folder, `index.html`, `package.json`, `vite.config.ts`, `tsconfig.json` and `.replit` over it).
2. Press **Run**. It runs `npm install && npm run dev` and opens the webview on port 5173.

Already have an app? Copy `src/game/` and `src/components/SchoolGameView.tsx` into it, run `npm install phaser`, then render `<SchoolGameView height="100vh" />` on any route. Your existing routes stay as they are.

## What's inside
```
src/
  game/
    art/        pixel.ts (canvas helpers, 3x5 font) · tiles.ts (floors, walls, wall decor)
                furniture.ts (40+ props + emote bubbles) · characters.ts (chibi sprite sheets)
    data/       schoolMap.ts (rooms, walls, doors) · furniture.ts (props, seats, interactables)
                schedule.ts (bell schedule, classes, 28 people) · dialogue.ts (chatter, quizzes)
    entities/   Character.ts (walk/sit animation, emotes, depth sorting)
    systems/    Pathfinding.ts (A*) · NPCSystem.ts (daily routines) · GameState.ts (save/grades)
                Audio.ts (WebAudio bell, piano, drums)
    scenes/     SchoolScene.ts (clock, player, interactions, objectives, map, report card)
    ui/         Hud.ts + styles.ts (HUD, D-pad, dialogs, character creator, mini-games)
    SchoolGame.ts            createSchoolGame(element)
  components/SchoolGameView.tsx   React wrapper
  App.tsx · main.tsx
```

## Gameplay
- **Bell schedule:** 7:30 arrival → 6 periods with passing time → lunch → clubs → 2:40 bus home.
- **Living NPCs:** 17 students in 3 homerooms walk to their own classes, stop at lockers, queue for lunch,
  pick clubs by personality, chat in the halls and ride the bus. Teachers greet at doors and eat lunch; the chef,
  principal, janitor and office staff keep their own routines.
- **You:** customize your student, grab books from locker ★7, get to class on time, answer pop quizzes,
  eat lunch, play piano/drums, paint, shoot free throws, run lab experiments, read books and make friends.
- **Report card** at the end of each day with attendance, letter grades, stats and friends. Progress autosaves.

Controls: arrow keys/WASD or the D-pad · E/Space/Enter or the red A button · tap anywhere to walk there ·
M opens the map · the 1× button changes game speed · ⏩ skips to the bell while you're seated.

## Customize
- **Add a room:** add it to `ROOMS` in `data/schoolMap.ts`, carve a door in `DOORS`, then place props and seats in `data/furniture.ts`.
- **Change the timetable:** edit `PERIODS` and `GROUP_SCHEDULE` in `data/schedule.ts`.
- **New students/teachers:** add names to `STUDENT_NAMES` or call `teacher(...)` in `buildRoster()`.
- **New prop art:** add an entry to `FURNITURE` in `art/furniture.ts` (width, height, draw function).
