// Entry used for the single-file web build (no React).
import { createSchoolGame } from './game/SchoolGame';

(window as any).__school = createSchoolGame(document.getElementById('game')!);
